public class CalculadoraApp {
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(VentanaCalculadora::new);
    }
}
