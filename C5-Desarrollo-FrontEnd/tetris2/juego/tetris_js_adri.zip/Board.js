import { Tetromino } from './Tetromino.js';

export class Board {
  constructor(width=10, height=20) {
    this.width = width;
    this.height = height;
    this.grid = this.createGrid();
  }

  createGrid() {
    const grid = [];
    for(let y=0; y < this.height; y++) {
      grid.push(new Array(this.width).fill(0));
    }
    return grid;
  }

  collide(tetromino, pos) {
    const m = tetromino.matrix;
    for(let y=0; y < m.length; y++) {
      for(let x=0; x < m[y].length; x++) {
        if (m[y][x] !== 0) {
          let newX = x + pos.x;
          let newY = y + pos.y;
          if (newX < 0 || newX >= this.width || newY >= this.height || (newY >= 0 && this.grid[newY][newX] !== 0)) {
            return true;
          }
        }
      }
    }
    return false;
  }

  merge(tetromino, pos) {
    const m = tetromino.matrix;
    for(let y=0; y < m.length; y++) {
      for(let x=0; x < m[y].length; x++) {
        if (m[y][x] !== 0) {
          this.grid[pos.y + y][pos.x + x] = m[y][x];
        }
      }
    }
  }

  clearLines() {
    let linesCleared = 0;
    outer: for(let y = this.height-1; y >= 0; y--) {
      for(let x=0; x < this.width; x++) {
        if(this.grid[y][x] === 0) {
          continue outer;
        }
      }
      this.grid.splice(y,1);
      this.grid.unshift(new Array(this.width).fill(0));
      linesCleared++;
      y++;
    }
    return linesCleared;
  }
}