import { Board } from './Board.js';
import { Tetromino } from './Tetromino.js';

export class GamePanel {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.board = new Board();
    this.score = 0;
    this.level = 1;
    this.lines = 0;

    this.currentPiece = null;
    this.piecePos = {x: 3, y: 0};

    this.dropInterval = 1000;
    this.dropCounter = 0;
    this.lastTime = 0;

    this.initControls();
    this.reset();
    this.update();
  }

  reset() {
    this.board.grid = this.board.createGrid();
    this.score = 0;
    this.level = 1;
    this.lines = 0;
    this.spawnPiece();
  }

  spawnPiece() {
    const types = ['I','O','T','S','Z','J','L'];
    const type = types[Math.floor(Math.random() * types.length)];
    this.currentPiece = new Tetromino(type);
    this.piecePos = {x: Math.floor(this.board.width/2) - Math.floor(this.currentPiece.matrix[0].length/2), y: 0};

    if(this.board.collide(this.currentPiece, this.piecePos)) {
      this.reset();
    }
  }

  move(offsetX) {
    const newPos = {x: this.piecePos.x + offsetX, y: this.piecePos.y};
    if(!this.board.collide(this.currentPiece, newPos)) {
      this.piecePos = newPos;
    }
  }

  drop() {
    const newPos = {x: this.piecePos.x, y: this.piecePos.y + 1};
    if(!this.board.collide(this.currentPiece, newPos)) {
      this.piecePos = newPos;
    } else {
      this.board.merge(this.currentPiece, this.piecePos);
      const cleared = this.board.clearLines();
      if(cleared > 0) {
        this.lines += cleared;
        this.score += cleared * 100;
        if(this.lines >= this.level * 10) {
          this.level++;
          this.dropInterval *= 0.9;
        }
      }
      this.spawnPiece();
    }
  }

  rotate(dir) {
    this.currentPiece.rotate(dir);
    if(this.board.collide(this.currentPiece, this.piecePos)) {
      this.currentPiece.rotate(-dir);
    }
  }

  update(time = 0) {
    const deltaTime = time - this.lastTime;
    this.lastTime = time;
    this.dropCounter += deltaTime;
    if(this.dropCounter > this.dropInterval) {
      this.drop();
      this.dropCounter = 0;
    }
    this.draw();
    requestAnimationFrame(this.update.bind(this));
  }

  draw() {
    this.ctx.fillStyle = '#000';
    this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

    this.drawMatrix(this.board.grid, {x:0, y:0});
    this.drawMatrix(this.currentPiece.matrix, this.piecePos);

    this.ctx.fillStyle = 'white';
    this.ctx.font = '20px Arial';
    this.ctx.fillText(`Score: ${this.score}`, 10, 30);
    this.ctx.fillText(`Level: ${this.level}`, 10, 60);
    this.ctx.fillText(`Lines: ${this.lines}`, 10, 90);
  }

  drawMatrix(matrix, offset) {
    const blockSize = 30;
    for(let y=0; y < matrix.length; y++) {
      for(let x=0; x < matrix[y].length; x++) {
        if(matrix[y][x] !== 0) {
          this.ctx.fillStyle = this.getColor(matrix[y][x]);
          this.ctx.fillRect((x + offset.x) * blockSize, (y + offset.y) * blockSize, blockSize - 1, blockSize -1);
        }
      }
    }
  }

  getColor(num) {
    const colors = [
      null,
      '#00ffff',
      '#ffff00',
      '#800080',
      '#00ff00',
      '#ff0000',
      '#0000ff',
      '#ffa500',
    ];
    return colors[num];
  }

  initControls() {
    window.addEventListener('keydown', event => {
      switch(event.key) {
        case 'ArrowLeft':
          this.move(-1);
          break;
        case 'ArrowRight':
          this.move(1);
          break;
        case 'ArrowDown':
          this.drop();
          break;
        case 'q':
        case 'Q':
          this.rotate(-1);
          break;
        case 'w':
        case 'W':
          this.rotate(1);
          break;
      }
    });
  }
}