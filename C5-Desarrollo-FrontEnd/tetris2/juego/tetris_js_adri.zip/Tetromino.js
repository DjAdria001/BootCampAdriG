export class Tetromino {
  constructor(type) {
    this.type = type;
    this.matrix = this.createMatrix(type);
    this.x = 0;
    this.y = 0;
  }

  createMatrix(type) {
    switch(type) {
      case 'I':
        return [
          [0,0,0,0],
          [1,1,1,1],
          [0,0,0,0],
          [0,0,0,0]
        ];
      case 'O':
        return [
          [2,2],
          [2,2]
        ];
      case 'T':
        return [
          [0,3,0],
          [3,3,3],
          [0,0,0]
        ];
      case 'S':
        return [
          [0,4,4],
          [4,4,0],
          [0,0,0]
        ];
      case 'Z':
        return [
          [5,5,0],
          [0,5,5],
          [0,0,0]
        ];
      case 'J':
        return [
          [6,0,0],
          [6,6,6],
          [0,0,0]
        ];
      case 'L':
        return [
          [0,0,7],
          [7,7,7],
          [0,0,0]
        ];
    }
  }

  rotate(dir) {
    for(let y=0; y < this.matrix.length; y++) {
      for(let x=0; x < y; x++) {
        [this.matrix[x][y], this.matrix[y][x]] = [this.matrix[y][x], this.matrix[x][y]];
      }
    }
    if (dir > 0) {
      this.matrix.forEach(row => row.reverse());
    } else {
      this.matrix.reverse();
    }
  }
}